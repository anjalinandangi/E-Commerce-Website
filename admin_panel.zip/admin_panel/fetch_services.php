<?php
include "config.php";

$result = $conn->query("SELECT * FROM services ORDER BY id DESC");

if ($result->num_rows == 0) {
    echo "<p>No services found</p>";
    exit;
}

while ($row = $result->fetch_assoc()) {
    echo "
    <div class='service-card'>
        <img src='images/{$row['image']}' alt='Service'>
        <div class='content'>
            <h4>{$row['service_name']}</h4>
            <p>{$row['description']}</p>
            <button onclick='deleteService({$row['id']})'>Delete</button>
        </div>
    </div>
    ";
}
?>
