<?php
include 'config.php';

$name = $_POST['service_name'];
$desc = $_POST['description'];

$imageName = time() . "_" . $_FILES['image']['name'];
$targetDir = "uploads/";

if (!is_dir($targetDir)) {
    mkdir($targetDir, 0777, true);
}

$targetFile = $targetDir . $imageName;

if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
    $stmt = $conn->prepare("INSERT INTO services (service_name, description, image) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $desc, $imageName);
    $stmt->execute();

    echo "<span style='color:green'>Service added successfully</span>";
} else {
    echo "<span style='color:red'>Image upload failed</span>";
}
