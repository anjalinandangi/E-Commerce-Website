<?php include 'auth-header.php'; ?>

<section class="login-section">
    <div class="login-card">
        <div class="login-header">
            <img src="images/logoimg">
            <h2>Sweet sectors</h2>
            <p>Login to enjoy sweet moments</p>
        </div>

        <form id="loginForm">
            <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>

            <button type="submit" class="login-btn">Login</button>
            <p id="loginMsg"></p>
        </form>

        <div class="links">
            <a href="register.php">Create Account</a>
        </div>
    </div>
</section>

<script>
document.getElementById("loginForm").addEventListener("submit", function(e){
    e.preventDefault();

    let formData = new FormData(this);

    fetch("login_process.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        if (data.trim() === "success") {
            window.location.href = "dashboard.php"; // ✅ correct path
        } else {
            document.getElementById("loginMsg").innerHTML = data;
        }
    });
});
</script>



</body>
</html>
