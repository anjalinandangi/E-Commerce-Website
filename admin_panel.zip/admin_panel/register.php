<?php include 'auth-header.php'; ?>

<section class="auth-section">
    <div class="auth-card">
        <h2>Create Account 🎂</h2>
        <p>Join us for delicious cake moments</p>

        <form id="registerForm" method="post" action="register_process.php">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="number" name="phoneno" placeholder="Phone No" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>

            <button type="submit" class="auth-btn">Register</button>
            <p id="regMsg"></p>
        </form>

        <div class="auth-links">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </div>
</section>

</body>
</html>
