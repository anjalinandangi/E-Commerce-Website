<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Fetch services
$result = mysqli_query($conn, "SELECT * FROM services ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Service List | Bakery Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- HEADER -->
<header class="admin-header">
    <div class="logo">
        Bakery Admin
    </div>

    <nav class="admin-nav">
        <div class="dropdown">
            <button class="dropbtn">Services ▾</button>
            <div class="dropdown-content">
                <a href="dashboard.php">Add Service</a>
                <a href="service_list.php">Service List</a>
            </div>
        </div>

        <a href="logout.php" class="logout-btn">Logout</a>
    </nav>
</header>

<!-- CONTENT -->
<main class="dashboard-content">

    <h1>Service List 🍰</h1>

    <div class="table-card">
        <table class="service-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Image</th>
                    <th>Service Name</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    $i = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?php echo $i++; ?></td>

                    <td>
                        <img src="uploads/<?php echo $row['image']; ?>" class="table-img">
                    </td>

                    <td><?php echo htmlspecialchars($row['service_name']); ?></td>

                    <td><?php echo htmlspecialchars($row['description']); ?></td>

                    <td class="action-buttons">

                        <a href="edit_service.php?id=<?php echo $row['id']; ?>"
                        class="edit-btn">
                        Edit
                        </a>

                        <a href="delete_service.php?id=<?php echo $row['id']; ?>"
                        class="delete-btn"
                        onclick="return confirm('Delete this service?')">
                        Delete
                        </a>

                    </td>

                </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='5' style='text-align:center;'>No services found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

</main>

</body>
</html>
