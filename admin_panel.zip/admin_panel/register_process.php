<?php
include '../config.php';

/* ================= VALIDATE REQUEST ================= */
if (
    !isset($_POST['name'], $_POST['email'], $_POST['phoneno'],
            $_POST['password'], $_POST['confirm_password'])
) {
    echo "<span style='color:red'>Invalid request</span>";
    exit;
}

$name  = trim($_POST['name']);
$email = trim($_POST['email']);
$phone = trim($_POST['phoneno']);
$pass  = $_POST['password'];
$cpass = $_POST['confirm_password'];

/* ================= BASIC VALIDATION ================= */
if ($name === '' || $email === '' || $phone === '' || $pass === '' || $cpass === '') {
    echo "<span style='color:red'>All fields are required</span>";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<span style='color:red'>Invalid email format</span>";
    exit;
}

if (!preg_match('/^[0-9]{10}$/', $phone)) {
    echo "<span style='color:red'>Invalid phone number</span>";
    exit;
}

if ($pass !== $cpass) {
    echo "<span style='color:red'>Passwords do not match</span>";
    exit;
}

/* ================= CHECK EMAIL EXISTS ================= */
$check = $conn->prepare("SELECT id FROM users WHERE email = ?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "<span style='color:red'>Email already registered</span>";
    exit;
}
$check->close();

/* ================= INSERT USER ================= */
$hashed = password_hash($pass, PASSWORD_DEFAULT);

$stmt = $conn->prepare(
    "INSERT INTO users (name, email, phoneno, password) VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("ssss", $name, $email, $phone, $hashed);

if ($stmt->execute()) {
    echo "success";   // 🔥 clean AJAX response
} else {
    echo "<span style='color:red'>Registration failed</span>";
}

$stmt->close();
$conn->close();
