<?php
session_start();              // 🔴 REQUIRED
include '../config.php';

/* ================= BASIC VALIDATION ================= */
if (!isset($_POST['email'], $_POST['password'])) {
    echo "<span style='color:red'>Invalid request</span>";
    exit;
}

$email = trim($_POST['email']);
$pass  = $_POST['password'];

if ($email === '' || $pass === '') {
    echo "<span style='color:red'>All fields are required</span>";
    exit;
}

/* ================= CHECK USER ================= */
$stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {

    $row = $result->fetch_assoc();

    if (password_verify($pass, $row['password'])) {

        // ✅ LOGIN SUCCESS
        $_SESSION['user_id']   = $row['id'];
        $_SESSION['user_name'] = $row['name'];

        echo "success";

    } else {
        echo "<span style='color:red'>Invalid password</span>";
    }

} else {
    echo "<span style='color:red'>Account not found</span>";
}

$stmt->close();
$conn->close();
