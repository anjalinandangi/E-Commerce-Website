<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Service</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="admin-header">
    <div class="logo">Bakery Admin</div>
    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php" class="logout-btn">Logout</a>
    </nav>
</header>

<main class="dashboard-content">
    <h1>Add New Service</h1>

    <div class="form-card">
        <form id="serviceForm" enctype="multipart/form-data">
            <div class="input-group">
                <label>Service Name</label>
                <input type="text" name="service_name" required>
            </div>

            <div class="input-group">
                <label>Description</label>
                <textarea name="description" rows="4" required></textarea>
            </div>

            <div class="input-group">
                <label>Image</label>
                <input type="file" name="image" required>
            </div>

            <button type="submit">Add Service</button>
            <p id="serviceMsg"></p>
        </form>
    </div>
</main>

<script>
document.getElementById("serviceForm").addEventListener("submit", function(e){
    e.preventDefault();

    let formData = new FormData(this);

    fetch("add_service_ajax.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        document.getElementById("serviceMsg").innerHTML = data;
        this.reset();
    });
});
</script>

</body>
</html>
