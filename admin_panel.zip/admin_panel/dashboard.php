<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get service count
$result = $conn->query("SELECT COUNT(*) AS total FROM services");
$row = $result->fetch_assoc();
$serviceCount = $row['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="admin-header">
    <div class="logo">
    <img src="images/meat-pie_3537466.png" alt="Bakery Logo">
    <span>Bakery Admin</span>
    </div>

    <nav class="admin-nav">

        <div class="dropdown">
            <button class="dropbtn">Services ▾</button>
            <div class="dropdown-content">
                <a href="add_service.php">Add Service</a>
                <a href="service_list.php">Service List</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Products ▾</button>
            <div class="dropdown-content">
                <a href="add_service.php">Add Products</a>
                <a href="service_list.php">Products List</a>
            </div>
        </div>

        <a href="logout.php" class="logout-btn">Logout</a>
    </nav>
</header>

<main class="dashboard-content">
    <h1>Welcome, <?= $_SESSION['user_name']; ?> 👋</h1>
    <h3>Dashboard Overview</h3>

    <div class="dashboard-cards">

    <div class="dash-card">
        <div class="dash-icon">🛠️</div>
        <h3>Total Services</h3>
        <p><?= $serviceCount ?></p>
        <a href="service_list.php">View Services</a>
    </div>

    <div class="dash-card">
        <div class="dash-icon">➕</div>
        <h3>Add New Service</h3>
        <p>+</p>
        <a href="add_service.php">Add Service</a>
    </div>

    <!-- ✅ NEW EDIT SERVICE CARD -->
    <div class="dash-card">
        <div class="dash-icon">✏️</div>
        <h3>Edit Services</h3>
        <p>Update</p>
        <a href="service_list.php">Edit Service</a>
    </div>

    </div>

</main>

</body>
</html>
